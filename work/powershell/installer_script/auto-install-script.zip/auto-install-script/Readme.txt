1. open a powershell terminal, type in: 
   Set-ExecutionPolicy Unrestricted 
2. right click file select >> Run with powershell
3. a log file will be create named by the computer name entered. s