a='dd'
eval(a+"=4")
p dd
