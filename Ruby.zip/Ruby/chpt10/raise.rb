raise
simply reraises the current exception

raise "bad mp3 encoding"
creates a new runtimeerror exception, setting its message to the given string.

raise InterfaceException, "Keyboard failure", caller
