99.times do |n|
    p n
end
