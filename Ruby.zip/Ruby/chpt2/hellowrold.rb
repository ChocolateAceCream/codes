puts "hello"

puts "gin joint".length
#asks a string for its length

puts "Rick".index("c")

#asks a different string to find the index of the letter c
#index starts from 0

puts 42.even?
#asks the number 42 if it is even (the question mark is part of the method)

num=-1234
positive =  num.abs
puts positive
# asks the abs value